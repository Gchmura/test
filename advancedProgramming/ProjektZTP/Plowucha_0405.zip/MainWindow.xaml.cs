﻿using Ionic.Zip;
using ProjektZTP.gw1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjektZTP
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //WebClient client = new WebClient();
            //client.DownloadFile(
            //    "https://www.bankier.pl/inwestowanie/profile/quote.html?symbol=WIG",
            //    "file.html");

            //client.DownloadFile(
            //"http://bossa.pl/pub/metastock/mstock/mstall.zip",
            //"file2.zip");

            //Assembly ass = Assembly.GetExecutingAssembly();
            //string path = System.IO.Path.GetDirectoryName(ass.Location);


            //using (ZipFile zip = ZipFile.Read(path + "\\file2.zip"))
            //{
            //    zip.ExtractAll(path + "\\extracted");

            //}
            ////komunikaty o bledach => do pliku
            //MessageBox.Show("ok");

            DownloadService d0 = new DownloadService();

            d0.DownloadFile(1, 1);



            Download d = new DownloadFromBossa(new ErrorMessageToFile());

            d.DownloadFile();



            

            Operations operations = new Operations();
            operations.Read();
            operations.Calculate();
            operations.Write();






        }
    }
}
