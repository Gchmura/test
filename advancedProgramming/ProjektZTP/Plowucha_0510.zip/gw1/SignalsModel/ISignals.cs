﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektZTP.gw1.SignalsModel
{
    public interface ISignals
    {        
        List<(string dt, bool sg)> xx(List<(string dt, double pr)> D);
        string[] dates { get; set; }
        bool[] signals { get; set; }
    }
}
