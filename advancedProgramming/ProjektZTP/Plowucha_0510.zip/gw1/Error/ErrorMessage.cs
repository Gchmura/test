﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektZTP.gw1
{
    public abstract class ErrorMessage
    {
        public abstract void GetError(string message);
    }
}
