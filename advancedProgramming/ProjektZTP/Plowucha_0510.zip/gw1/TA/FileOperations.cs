﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektZTP.gw1
{
    public class FileOperations
    {
        public double[][] ReadData()
        {
            return new double[1][];
        }
    }
}
